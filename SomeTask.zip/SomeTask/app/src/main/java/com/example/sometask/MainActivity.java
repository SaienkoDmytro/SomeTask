package com.example.sometask;

import android.app.FragmentManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.FrameLayout;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity implements MyFragment1.DataPassListener {

    FrameLayout container;
    FragmentManager myFragmentManager;
    MyFragment1 myFragment1;
    MyFragment2 myFragment2;
    final static String TAG_1 = "FRAGMENT_1";
    final static String TAG_2 = "FRAGMENT_2";
    final static String KEY_MSG_1 = "FRAGMENT1_MSG";
    final static String KEY_MSG_2 = "FRAGMENT2_MSG";

    // activity Main method
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        container = findViewById(R.id.container);

        Button button1 = findViewById(R.id.buttonActivityMainFrag1);
        Button button2 = findViewById(R.id.buttonActivityMainFrag2);


        myFragmentManager = getFragmentManager();
        myFragment1 = new MyFragment1();
        myFragment2 = new MyFragment2();


        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .setReorderingAllowed(true)
                    .add(R.id.fragment_container_view, MyFragment1.class, null)
                    .addToBackStack(null)
                    .commit();
        }

        button1.setOnClickListener(arg0 -> {

            androidx.fragment.app.FragmentManager fragmentManager = getSupportFragmentManager();
            MyFragment1 fragment1 = (MyFragment1) fragmentManager.findFragmentByTag(TAG_1);

            if (fragment1 == null) {

                Bundle bundle = new Bundle();
                bundle.putString(KEY_MSG_1, "Заменили на первый фрагмент");
                myFragment1.setArguments(bundle);

                getSupportFragmentManager().beginTransaction()
                        .setReorderingAllowed(true)
                        .replace(R.id.fragment_container_view, MyFragment1.class, bundle)
                        .addToBackStack(null)
                        .commit();

            } else {
                fragment1.setMsg("Первый фрагмент уже загружен");
            }
        });

        button2.setOnClickListener(arg0 -> {

            androidx.fragment.app.FragmentManager fragmentManager = getSupportFragmentManager();
            MyFragment2 fragment2 = (MyFragment2) fragmentManager.findFragmentByTag(TAG_2);

            if (fragment2 == null) {

                Bundle bundle = new Bundle();
                bundle.putString(KEY_MSG_2, "Заменили на второй фрагмент");
                myFragment2.setArguments(bundle);

                getSupportFragmentManager().beginTransaction()
                        .setReorderingAllowed(true)
                        .replace(R.id.fragment_container_view, MyFragment2.class, bundle)
                        .addToBackStack(null)
                        .commit();

            } else {
                fragment2.setMsg("Второй фрагмент уже загружен");
            }
        });

    }

    @Override
    public void passData(String data) {
        MyFragment1 fragment1 = new MyFragment1();
        Bundle args = new Bundle();
        args.putString(MyFragment1.DATA_RECEIVE, data);
        fragment1 .setArguments(args);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container_view, fragment1)
                .commit();
    }

}